package com.capg.SpringLab11;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Application {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Employee emp = (Employee)context.getBean("employee");
		System.out.println("Employee Details");
		System.out.println("________________________");
		System.out.println("Emp Id- " + emp.getEmployeeId());
		System.out.println("Emp Name- " + emp.getEmployeeName());
		System.out.println("Emp Salary- " + emp.getSalary());
		System.out.println("Emp BU- " + emp.getBusinessUnit());
		System.out.println("Age- " + emp.getAge());
	}
}