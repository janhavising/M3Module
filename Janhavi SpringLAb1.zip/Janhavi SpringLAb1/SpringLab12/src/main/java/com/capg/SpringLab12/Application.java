package com.capg.SpringLab12;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Application {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Employee emp = context.getBean("emp", Employee.class);
		System.out.println("Employee Details");
		System.out.println("__________________________");
		System.out.println("[empAge=" + emp.getAge() + ", empId=" + emp.getEmployeeId() + ", empName="
				+ emp.getEmployeeName() + ", empSalary=" + emp.getSalary() + "]");
		System.out.println("SBU details details=[sbuCode=" + emp.getBusinessUnit().getSbuName() + ", sbuHead="
				+ emp.getBusinessUnit().getSbuHead() + ", sbuName=" + emp.getBusinessUnit().getSbuName() + "]");

	}
}
