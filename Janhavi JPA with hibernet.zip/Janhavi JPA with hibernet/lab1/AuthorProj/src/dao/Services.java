package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import bean.Author;

public class Services {

	static EntityManagerFactory emfactory=Persistence.createEntityManagerFactory("AuthorProj");
	static EntityManager entitymanager=emfactory.createEntityManager();

	public static void main(String[] args)
	{
		Services service= new Services();
		
		Author authorObj = new Author();
		authorObj.setAuthorId(201);
		authorObj.setFirstName("Jan");
		authorObj.setMiddleName("Singhh");
		authorObj.setLastName("Chauhaan");
		authorObj.setPhoneNo(777777777);
		service.InsertIntoAuthorDB(authorObj);
		
		Author authorObj1 = new Author();
		authorObj1.setAuthorId(202);
		authorObj1.setFirstName("Janvi");
		authorObj1.setMiddleName("S");
		authorObj1.setLastName("C");
		authorObj1.setPhoneNo(666666666);
		service.InsertIntoAuthorDB(authorObj1);
		//System.out.println("===========Authors========");
		Author a=service.GetAuthorDetails(201);
		System.out.println("Author id is:"+a.getAuthorId());
		System.out.println("Author name is:"+a.getName());
		System.out.println("Author phone no is:"+a.getPhoneNo());
		System.out.println();
		Author a2=service.GetAuthorDetails(202);
		System.out.println("author details");
		System.out.println("Author id is:"+a2.getAuthorId());
		System.out.println("Author name is:"+a2.getName());
		System.out.println("Author phone no is:"+a2.getPhoneNo());
		System.out.println();
		service.UpdateAuthor(202, 222222222);
		Author a1=service.GetAuthorDetails(202);
		System.out.println("Author id is:"+a1.getAuthorId());
		System.out.println("Author name is:"+a1.getName());
		System.out.println("Author phone no is:"+a1.getPhoneNo());
		service.DeleteAuthor(202);
	}
	public void InsertIntoAuthorDB(Author authorObj) {
		entitymanager.getTransaction().begin();
		entitymanager.persist(authorObj);
		entitymanager.getTransaction().commit();
		System.out.println("Author inserted successfully");
	}
	public void UpdateAuthor(int id,long phone) {
		entitymanager.getTransaction().begin();
		Author author = entitymanager.find(Author.class, id);
		author.setPhoneNo(phone);
		entitymanager.getTransaction().commit();
		System.out.println("Author phone no updated successfully");
	}
	Author GetAuthorDetails(int id) {
		Author author = entitymanager.find(Author.class, id);
		return author;
	}
	public void DeleteAuthor(int id) {
		entitymanager.getTransaction().begin();
		Author author = entitymanager.find(Author.class, id);
		entitymanager.remove(author);
		entitymanager.getTransaction().commit();
		System.out.println("Author deleted successfully");
	}
	
}