package com.sunsoft.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sunsoft.entity.TrainerSpringJPA;
import com.sunsoft.repository.ITrainerRepository;

@Service
public class ITrainerServiceImpl implements ITrainerService {

	@Autowired
	private ITrainerRepository trRepository;
	@Override
	public List<TrainerSpringJPA> getTrainer() {
		return trRepository.findAll();
	}

	public void saveTrainer(TrainerSpringJPA theTrainer) {
		trRepository.save(theTrainer);
		
	}

	public Optional<TrainerSpringJPA> getTrainer(int theId) {
		Optional<TrainerSpringJPA> employeeObj = trRepository.findById(theId);
		return employeeObj;
	}
	
	@Override
	@Transactional
	public void deleteTrainer(int theId) {
		trRepository.deleteById(theId);
		
	}

}
