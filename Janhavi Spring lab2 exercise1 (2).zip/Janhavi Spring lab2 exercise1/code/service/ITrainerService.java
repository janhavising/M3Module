package com.sunsoft.service;

import java.util.List;
import java.util.Optional;

import com.sunsoft.entity.TrainerSpringJPA;



public interface ITrainerService {

	public List <TrainerSpringJPA> getTrainer();
	public void saveTrainer(TrainerSpringJPA theTrainer);
	public Optional <TrainerSpringJPA> getTrainer(int theId);
	public void deleteTrainer(int theId);
	
	
}
