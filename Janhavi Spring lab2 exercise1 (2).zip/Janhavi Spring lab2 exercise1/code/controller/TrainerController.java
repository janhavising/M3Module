package com.sunsoft.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sunsoft.entity.TrainerSpringJPA;
import com.sunsoft.service.ITrainerService;



@Controller
@RequestMapping("/Trainer")
public class TrainerController {

	private static final Logger LOG = LoggerFactory.getLogger(TrainerController.class);
	
	@Autowired
	private ITrainerService trainerService;
	
	 
	
	@GetMapping("/list")
	public String listCustomer(Model theModel)
	{
		
		List<TrainerSpringJPA> theTrainer = trainerService.getTrainer();
		theModel.addAttribute("trainer", theTrainer);
		System.out.println("List of Data : "+theTrainer);
		return "list-trainer";		
	}
	
	@GetMapping("/showForm")
	 public String showFormForAdd(Model theModel){
		LOG.debug("inside show customer-form handler method");
		TrainerSpringJPA theTrainer = new TrainerSpringJPA();
		theModel.addAttribute("trainer",theTrainer);
		
		return "Trainer-form";	
		
	}
	
	@PostMapping("/saveTrainer")
	public String saveCustomer(@ModelAttribute("trainer") TrainerSpringJPA theTrainer)
	{
		trainerService.saveTrainer(theTrainer);
		return "redirect:/Trainer/list";
	}
	
	@GetMapping("/updateForm")
	public String showFormForUpdate(@RequestParam("trainerId") int theId, Model theModel){
		Optional<TrainerSpringJPA> theTrainer = trainerService.getTrainer(theId);
		theModel.addAttribute("trainer", theTrainer);
		return "Trainer-form";
		
	}
	@GetMapping("/delete")
	public String deleteCustomer(@RequestParam("trainerId") int theId){
		trainerService.deleteTrainer(theId);
		return "redirect:/Trainer/list";
	}
		
}
