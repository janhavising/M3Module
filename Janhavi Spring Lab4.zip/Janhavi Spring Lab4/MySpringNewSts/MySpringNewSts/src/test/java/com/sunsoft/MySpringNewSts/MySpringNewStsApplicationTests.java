package com.sunsoft.MySpringNewSts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringNewStsApplicationTests {

	@Test
	void contextLoads() {
	}

}
