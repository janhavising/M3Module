/*package com.sunsoft.MySpringNewSts.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

//@ControllerAdvice
public class GlobalExceptionHandler {

	/*@ExceptionHandler({InvalidProductIDException.class, InvalidProductNameException.class})
	public ResponseEntity<String> handleException(Exception ex)
	{
		if(ex instanceof InvalidProductIDException) {
			HttpStatus status =HttpStatus.NOT_FOUND;
			return new ResponseEntity("Invalid ProductID",status);
		} 
		else if(ex instanceof InvalidProductNameException) {
			HttpStatus status =HttpStatus.NOT_FOUND;
			return new ResponseEntity("Invalid ProductName",status);
		} 
		else
			return null;
			
		
		
	}
}*/
