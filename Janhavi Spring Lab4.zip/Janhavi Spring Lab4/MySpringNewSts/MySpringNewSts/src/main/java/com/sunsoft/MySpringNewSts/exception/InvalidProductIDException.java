/*package com.sunsoft.MySpringNewSts.exception;

public class InvalidProductIDException extends Exception{

	public InvalidProductIDException(String str)
	{
		super();
	}
}*/
