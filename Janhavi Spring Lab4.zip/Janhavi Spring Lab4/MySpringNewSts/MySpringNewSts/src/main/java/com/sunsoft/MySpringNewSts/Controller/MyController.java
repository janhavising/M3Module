package com.sunsoft.MySpringNewSts.Controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunsoft.entity.Employee;

/*import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//import com.sunsoft.MySpringNewSts.exception.InvalidProductIDException;
import com.sunsoft.MySpringNewSts.exception.InvalidProductNameException;*/

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/employee")
public class MyController {
	
	@GetMapping(path="/isValid", produces=MediaType.APPLICATION_JSON_VALUE)
	public Employee index(@RequestParam ("UserId") String UserId, @RequestParam ("Password") String Password)
	{
		System.out.println("In the EmployeeController.......Data received is UserId: "+UserId+" and password is:"+Password);
		String s=new String("Valid User");
		boolean retStr=true;
		if(!Password.equals("admin"))
		{
			s="Invalid User";
			retStr=false;
		}
		
		return new Employee(101,"Janhavi","CS");
		
	}
	
   
	/*@RequestMapping("/")
	public String func()
	{
		String s = "Hii...This is Janhavi Singh Chauhan";
		return s;
	}

	@GetMapping(path="/isValid", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> index123(@RequestParam ("ProductId") int ProductId,
			@RequestParam("ProductName") String ProductName)throws InvalidProductIDException, InvalidProductNameException
	
	{
		String strValidateProduct=new String();
		if(ProductId==0)
			throw new InvalidProductIDException("EXCEPTION:Invalid Product");
		else
			strValidateProduct="Valid Product";
		System.out.println("name value is:"+ProductName);
		if(ProductName.equals(""))
			throw new InvalidProductNameException("EXCEPTION:Invalid Product Name");
		
		return new ResponseEntity<> (strValidateProduct,HttpStatus.OK);
		
	}
	
	@ExceptionHandler (InvalidProductNameException.class)
	public ResponseEntity<String> handleException(Exception ex)
	{
		return new ResponseEntity (ex.getMessage(),HttpStatus.NOT_FOUND);
	}*/
	
	
	
	
	
	
}